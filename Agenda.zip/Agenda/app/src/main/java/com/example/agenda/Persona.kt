package com.example.agenda

class Persona(imagen:Int,nombre:String,apellido:String,Tel:Int) {
    var imagen:Int=0
    var nombre:String=""
    var apellido:String=""
    var Tel: Int=0
    init {
        this.imagen=imagen
        this.nombre=nombre
        this.apellido=apellido
        this.Tel=Tel
    }
}