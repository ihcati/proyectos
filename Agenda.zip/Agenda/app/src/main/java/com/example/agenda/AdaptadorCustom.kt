package com.example.agenda

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class AdaptadorCustom(var context:Context, items:ArrayList<Persona> ) :BaseAdapter(){

    var items:ArrayList<Persona>?=null

    init {
        this.items=items
    }
    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var holder:ViewHolder?=null
        var vista:View?=p1

        if(vista==null){
            vista=LayoutInflater.from(context).inflate(R.layout.template,null)
            holder=ViewHolder(vista)
            vista.tag=holder
        }
        else{
        holder=vista.tag as? ViewHolder
        }
        val item=getItem(p0) as Persona
        holder?.nombre?.text=item.nombre
        holder?.apellido?.text=item.apellido
        holder?.tel?.text=item.Tel.toString()
        holder?.imagen?.setImageResource(item.imagen)
        return vista!!
    }

    override fun getItem(p0: Int): Any {
        return items?.get(p0)!!
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getCount(): Int {
        return items?.count()!!
    }

    private class ViewHolder(vista:View){
        var nombre:TextView?=null
        var apellido:TextView?=null
        var tel:TextView?=null
        var imagen:ImageView?=null
        init {
            nombre=vista.findViewById(R.id.Nombre)
            apellido=vista.findViewById(R.id.Apellido)
            tel=vista.findViewById(R.id.Tel)
            imagen=vista.findViewById(R.id.imagen)
        }

    }
}