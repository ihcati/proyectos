package com.example.agenda

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var personas:ArrayList<Persona> =ArrayList()
        personas.add(Persona(R.drawable.chilin,"Juan","Lopez Martinez",95139999))
        personas.add(Persona(R.drawable.fuck,"Pedro","Santiago Sanchez",951555688))
        personas.add(Persona(R.drawable.megusta,"Hector","Hernandez Lopez",951234234))
        personas.add(Persona(R.drawable.poker2,"Maria","Perla Castillo",95123344))
        personas.add(Persona(R.drawable.mujer1,"Eliza","Jimez Lopez",95188899))
        personas.add(Persona(R.drawable.mujer2,"Andrea","Lopez Santiago",95188899))



        val lista=findViewById<ListView>(R.id.list)
        val adaptador=AdaptadorCustom(this,personas)
        lista.adapter=adaptador
    }
}
